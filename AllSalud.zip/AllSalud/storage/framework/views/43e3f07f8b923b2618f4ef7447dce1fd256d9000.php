<?php /* C:\xampp\htdocs\GitHub\AllSalud\AllSalud\resources\views/admin/getEstablecimientos.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<table class="table table-hover animated bounceInLeft">
	<thead>
		<tr>
			<th>id</th>
			<th>nombre</th>
			<th>ciudad</th>
			<th>actualizar</th>
		</tr>
	</thead>
	<tbody>


<?php $__currentLoopData = $establecimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $establecimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($establecimiento->id); ?></td>
		<td><?php echo e($establecimiento->nombre); ?></td>
		<td>
			<?php $__currentLoopData = $establecimiento->Domicilio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domicilio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($domicilio->ciudad_nombre); ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</td>
		<td>
			<a href="/admin/detalleEstablecimiento/<?php echo e($establecimiento->id); ?>/" >Actulizar/eliminar</a>
		</td>



	</tr>
	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	
<script>

</script>
<?php $__env->stopSection(); ?>





<br><br><br>


<?php echo $__env->make('admin.layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>