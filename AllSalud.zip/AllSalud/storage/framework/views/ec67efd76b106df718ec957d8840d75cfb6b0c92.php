<?php /* C:\xampp\htdocs\GitHub\AllSalud\AllSalud\resources\views/admin/home.blade.php */ ?>
<?php $__env->startSection('content'); ?>
	<h1>home</h1>
	<a href="/admin/altaEstablecimiento">Ingresar establecimiento</a>
	<br>
	<a href="/admin/getEstablecimientos">Actualizar/eliminar Establecimiento</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>