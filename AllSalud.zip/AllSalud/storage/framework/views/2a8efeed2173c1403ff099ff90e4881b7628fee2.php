<?php /* C:\xampp\htdocs\GitHub\AllSalud\AllSalud\resources\views/layouts/inc/scripts.blade.php */ ?>
<script type="text/javascript" src="/js/jquery.js"></script>
	<script type="text/javascript" src="/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/OwlCarousel2-2.3.4/dist/owl.carousel.min.js"></script>
	<script type="text/javascript" src="/js/slider.js"></script>