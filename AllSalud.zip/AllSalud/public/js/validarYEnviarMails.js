function validarYEnviarMails(){

	var nombre  = $("form #nombre").val();

	


}