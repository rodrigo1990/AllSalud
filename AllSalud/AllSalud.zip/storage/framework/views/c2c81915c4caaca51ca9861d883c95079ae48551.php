
	<footer class="padding-16">
			<ul>
				<li><b>Emergencias</b> 3220-8002</li>
				<li><b>Atención al socio</b> 3220-853</li>
			</ul>
	</footer>
<?php /**PATH C:\xampp\htdocs\GitHub\AllSalud\AllSalud\resources\views/footer.blade.php ENDPATH**/ ?>