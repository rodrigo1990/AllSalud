	<div class="slider-cont">
		<div class="absolute-div">
			<h3 class="bk-title">¡QUIERO ASOCIARME!</h3>
			<h2 class="nro margin-top-10">3220-8053</h2>
			<h1 class="margin-top-60 margin-bottom-20 main-title">Brindamos lo mejor <br> Para tu salud</h1>
			<a class="scroll-spy" href="#conoce-all">Conocenos</a>
		</div>
		<div class="owl-one owl-carousel owl-theme slider" id="owl-1">	

					<div>
						<div class="slide" id="slide-1">
							
						</div>
					</div>
					<div>
						<div class="slide" id="slide-2">
							
						</div>
					</div>

					<div>
						<div class="slide" id="slide-3">
							
						</div>
					</div>

					
		</div>		
	</div>
	<div class="slider-footer padding-16">
		<ul class="">
			<li><b>Emergencias</b> 3220-8002</li>
			<li><b>Atención al socio</b> 3220-8053</li>
		</ul>
	</div><?php /**PATH C:\xampp\htdocs\GitHub\AllSalud\AllSalud\resources\views/slider.blade.php ENDPATH**/ ?>